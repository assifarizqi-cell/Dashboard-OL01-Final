# Dashboard Web OL01 — Ria Busana

Aplikasi web dashboard ter-sinkronisasi untuk **Inventory, Sales Berjalan (H-1 Closing WIB), Permintaan Online (Fast Moving & Rising Star), Barang Masuk (Scan Barcode Kamera HP), dan Analisis Biaya Shopee**.

## Cara Upload & Publish ke GitHub Pages (Gratis & HTTPS)

1. **Buka repository GitHub kamu** (atau buat repository baru, misalnya `dashboard-ol01`, set ke **Public**).
2. Klik **Add file → Upload files**, lalu tarik/upload **ketiga file** dari folder ini (`index.html`, `data.js`, `README.md`), kemudian klik **Commit changes**.
3. Masuk ke **Settings → Pages**:
   - Pada **Source**, pilih **Deploy from a branch**.
   - Pilih branch **main** dan folder **/ (root)**, lalu klik **Save**.
4. Tunggu 1–2 menit hingga link `https://<username>.github.io/<nama-repo>/` muncul. Link HTTPS ini langsung bisa dibuka di HP maupun laptop semua anggota tim (termasuk fitur **Scan Barcode Kamera Belakang HP** di tab Barang Masuk).

## Struktur File
- `index.html` — Seluruh tampilan, grafik, logika upload Excel/CSV, kalkulator Shopee, dan scanner barcode (ringan & mudah diedit langsung di GitHub).
- `data.js` — Data awal Master Inventory (659 artikel), Analisis Biaya Shopee, dan peta 2.206 barcode SKU ID.
